Terminal compiling commands(for server4.cpp and client6.cpp):
g++ (filename.cpp) -lboost_system -boost_thread -std=c++11 -o (output)

To compile GUI Qt is required.